#############################################################
# FILE : lab1.py
# WRITER : your_name , your_login , your_id
# EXERCISE : intro2cs1 lab1 2023
# DESCRIPTION: A simple program that prints "Hello World!" to
# the standard output (screen).
#############################################################

print("Hello World!")