TGREEN =  '\033[32;40m' 
TRED = '\33[31m' 
TBLUE = '\33[34m' 
TYELLOW= '\33[33;40m'
ENDC = '\033[m'
BLACKB = '\033[40m'

def init_board():
    board = []
    row_number = 1
    print(TGREEN + '========Welcone to NIM game! lets set the board=======' + ENDC)
    while True:
        user_input = int(input(f'{BLACKB} Enter the number of matches \
in pile number {row_number}(to exit enter -1): {ENDC}'))
        row_number += 1
        if user_input == -1:
            break
        elif user_input  <= 0 or user_input % 1 != 0:
            print (f'{BLACKB} Please enter a positive integer')
            row_number -= 1
            continue
        else:
            board.append(user_input)
    print("---------------------------------------------")
    return board

def get_next_player(turn):
    if turn == 2:
        turn = 1 
        return turn
       
    if turn == 1 :
        turn = 2
        return turn 

def get_input(board):
    pile = int(input(f'{TYELLOW} Enter a valid number of pile \
(between 1 and {len(board)}): {ENDC}')) - 1
    while check_row_number_validity(pile,board) == False:
        pile = int(input(f'{TYELLOW} Try again,enter a a valid \
number of pile (between 1 and {len(board)}): {ENDC}')) - 1
    
    take = int(input(f'{TYELLOW} Enter a valid number of matches \
to remove (between 1 and {board[pile]}): {ENDC}'))   
    while check_amount_taken(pile, take, board) == False: 
        take = int(input(f'{TYELLOW} Try again,enter a valid number\
of matches to remove (between 1 and {board[pile]}): {ENDC}'))
    return int(take),int(pile)

def check_row_number_validity(pile, board):
    if pile >= len(board) or pile < 0 :
        return False
    return True

def check_amount_taken(pile, take , board):
    if check_row_number_validity == False:
        return False
    if board[pile] - take < 0 or take < 1:
        return False
    return True

def is_board_empty(board):
    if len(board)  == 0:
        return True
    return False

def print_board(board):
    print(TBLUE + '--------------current board status-----------' + ENDC)
    for i in board:
        print()
        for j in range(i):
            print(TBLUE+" | " +ENDC, end = '')
        print()
    print(TBLUE+'---------------------------------------------'+ENDC)

def update_board(board, pile, take):
    if check_amount_taken(pile, take , board) == False and \
        check_row_number_validity(pile, board) == False:
        print("number of matches and number of pile is invalid")
    elif check_amount_taken(pile, take , board) == False:
            print("number of matches is invalid")
    elif check_row_number_validity(pile, board) == False:
            print("number of pile is invalid")
    else:
        board[pile] -= take 
    for i in range(0,-len(board),-1):
        if board[i] == 0:
            del board[i]
    return board
    
def run_game():
    turn = 1
    board = init_board()
    while True:
        print("---------------------------------------------")
        if is_board_empty(board) == True:
            print(f'{TRED}The loser is player {turn}{ENDC}')
            turn = get_next_player(turn)
            print(f'{TGREEN}The WINNER is player {turn }{ENDC}')
            break
        print_board(board)
        print()

        print(f'{BLACKB}this is player {turn } turn{ENDC}')
        turn = get_next_player(turn)
        
        take, pile = get_input(board)
        update_board(board, pile, take)
        
    
if __name__ == '__main__':
    run_game()